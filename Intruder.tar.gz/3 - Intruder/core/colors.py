import sys

colors = True # Output should be colored
machine = sys.platform # Detecting the os of current system
if machine.lower().startswith(('os', 'win', 'darwin', 'ios')):
    colors = False # Colors shouldn't be displayed in mac & windows
if not colors:
    end = red = white = green = yellow = run = bad = good = info = que = tab = bold = underline = separator\
        = ''
else:
    white = '\033[97m'
    green = '\033[92m'
    red = '\033[91m'
    yellow = '\033[93m'
    
    underline = '\033[4m'
    bold = '\033[1m'
    
    info = '\033[93m\033[1m[!]\033[0m'
    que = '\033[94m\033[1m[?]\033[0m'
    bad = '\033[91m\033[1m[X]\033[0m'
    good = '\033[92m\033[1m[V]\033[0m'
    run = '\033[97m\033[1m[>>]\033[0m'
    
    tab = '\t'
    separator = '------------------------------------------------------------------\n'
    separator_no_new_line = '------------------------------------------------------------------'
    end = '\033[0m'
